<?php
// Superglobals helper
